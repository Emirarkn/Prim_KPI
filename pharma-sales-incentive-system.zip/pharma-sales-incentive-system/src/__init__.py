"""
Pharma Sales Incentive Management System

İlaç sektörü için saha satış yönetimi ve prim hesaplama sistemi.
"""

__version__ = "1.0.0"
__author__ = "Emir"
