"""
Pharma Sales Incentive System - Ana Uygulama
Flet tabanlı modern kullanıcı arayüzü
"""

from __future__ import annotations
import flet as ft
from pathlib import Path
import sys
import os
from typing import Optional

# Proje kök dizinini path'e ekle
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data_loader import DataLoader
from src.incentive_calculator import IncentiveCalculator
from src.report_generator import ReportGenerator


class PharmaSalesApp:
    """Ana uygulama sınıfı"""
    
    def __init__(self, page: ft.Page):
        self.page = page
        self.data_loader = DataLoader()
        self.calculator = IncentiveCalculator()
        self.report_gen = ReportGenerator()
        
        # State
        self.current_view: str = "dashboard"
        self.loaded_data: dict = {}
        self.loaded_files: dict[str, str | None] = {
            "target": None,
            "sellout": None,
            "visit": None,
            "order": None
        }
        
        # File picker referansları
        self.file_pickers: dict[str, ft.FilePicker] = {}
        
        # Status text referansları
        self.file_status_texts: dict[str, ft.Text] = {}
        
        self.setup_page()
        self.setup_file_pickers()
        self.build_ui()
    
    def setup_page(self):
        """Sayfa ayarları"""
        self.page.title = "Pharma Sales Incentive System"
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.padding = 0
        self.page.window.width = 1200
        self.page.window.height = 800
        self.page.window.min_width = 800
        self.page.window.min_height = 600
    
    def setup_file_pickers(self):
        """Dosya seçici dialoglarını oluştur"""
        file_types = ["target", "sellout", "visit", "order"]
        
        for file_type in file_types:
            picker = ft.FilePicker(
                on_result=lambda e, ft=file_type: self.on_file_picked(e, ft)
            )
            self.file_pickers[file_type] = picker
            self.page.overlay.append(picker)
    
    def on_file_picked(self, e: ft.FilePickerResultEvent, file_type: str):
        """Dosya seçildiğinde çağrılır"""
        if e.files and len(e.files) > 0:
            file_path = e.files[0].path
            file_name = e.files[0].name
            
            self.loaded_files[file_type] = file_path
            
            # Status text'i güncelle
            if file_type in self.file_status_texts:
                self.file_status_texts[file_type].value = f"✅ {file_name}"
                self.file_status_texts[file_type].color = ft.Colors.GREEN_700
            
            # Snackbar göster
            self.show_snackbar(f"✅ {file_name} dosyası yüklendi!")
            
            self.page.update()
    
    def show_snackbar(self, message: str, color: Optional[str] = None) -> None:
        """Snackbar göster - Flet'in yeni API'si"""
        snack = ft.SnackBar(
            content=ft.Text(message, color=ft.Colors.WHITE),
            bgcolor=color if color else ft.Colors.BLUE_700,
            duration=3000,
        )
        self.page.overlay.append(snack)
        snack.open = True
        self.page.update()
    
    def build_ui(self):
        """Ana UI yapısını oluştur"""
        # Sol menü
        self.nav_rail = ft.NavigationRail(
            selected_index=0,
            label_type=ft.NavigationRailLabelType.ALL,
            min_width=100,
            min_extended_width=200,
            destinations=[
                ft.NavigationRailDestination(
                    icon=ft.Icons.DASHBOARD_OUTLINED,
                    selected_icon=ft.Icons.DASHBOARD,
                    label="Dashboard",
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icons.UPLOAD_FILE_OUTLINED,
                    selected_icon=ft.Icons.UPLOAD_FILE,
                    label="Veri Yükle",
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icons.ANALYTICS_OUTLINED,
                    selected_icon=ft.Icons.ANALYTICS,
                    label="Performans",
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icons.PAYMENTS_OUTLINED,
                    selected_icon=ft.Icons.PAYMENTS,
                    label="Prim",
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icons.DESCRIPTION_OUTLINED,
                    selected_icon=ft.Icons.DESCRIPTION,
                    label="Raporlar",
                ),
                ft.NavigationRailDestination(
                    icon=ft.Icons.SETTINGS_OUTLINED,
                    selected_icon=ft.Icons.SETTINGS,
                    label="Ayarlar",
                ),
            ],
            on_change=self.nav_change,
        )
        
        # Ana içerik alanı
        self.content_area = ft.Container(
            content=self.build_dashboard(),
            expand=True,
            padding=20,
        )
        
        # Ana layout
        self.page.add(
            ft.Row(
                [
                    self.nav_rail,
                    ft.VerticalDivider(width=1),
                    self.content_area,
                ],
                expand=True,
            )
        )
    
    def nav_change(self, e):
        """Navigasyon değişikliği"""
        views = {
            0: self.build_dashboard,
            1: self.build_data_import,
            2: self.build_performance,
            3: self.build_incentive,
            4: self.build_reports,
            5: self.build_settings,
        }
        
        self.content_area.content = views.get(e.control.selected_index, self.build_dashboard)()
        self.page.update()
    
    def build_dashboard(self):
        """Dashboard görünümü"""
        # Yüklenen dosya sayısı
        loaded_count = sum(1 for v in self.loaded_files.values() if v is not None)
        
        return ft.Column(
            [
                ft.Text("📊 Dashboard", size=28, weight=ft.FontWeight.BOLD),
                ft.Divider(),
                ft.Row(
                    [
                        self._create_stat_card("Toplam ST", "24", ft.Colors.BLUE),
                        self._create_stat_card("Aktif Bölge", "4", ft.Colors.GREEN),
                        self._create_stat_card("Bölge Müdürü", "6", ft.Colors.ORANGE),
                        self._create_stat_card("Yüklenen Dosya", str(loaded_count), ft.Colors.PURPLE),
                    ],
                    wrap=True,
                ),
                ft.Container(height=20),
                ft.Text("📈 Çeyreklik Özet", size=20, weight=ft.FontWeight.W_500),
                ft.Container(
                    content=ft.Column([
                        ft.Text(
                            "Veri yükledikten sonra performans özeti burada görünecek." 
                            if loaded_count == 0 
                            else f"{loaded_count}/4 dosya yüklendi. Tüm dosyaları yükleyip 'Tümünü İşle' butonuna tıklayın.",
                            color=ft.Colors.GREY_600,
                        ),
                        ft.Container(height=10),
                        ft.ProgressBar(
                            value=loaded_count / 4,
                            bgcolor=ft.Colors.GREY_300,
                            color=ft.Colors.BLUE,
                            width=300,
                        ) if loaded_count > 0 else ft.Container(),
                    ]),
                    padding=20,
                    bgcolor=ft.Colors.GREY_100,
                    border_radius=10,
                ),
            ],
            scroll=ft.ScrollMode.AUTO,
        )
    
    def _create_stat_card(self, title: str, value: str, color: str):
        """İstatistik kartı oluştur"""
        return ft.Container(
            content=ft.Column(
                [
                    ft.Text(title, size=14, color=ft.Colors.GREY_600),
                    ft.Text(value, size=32, weight=ft.FontWeight.BOLD, color=color),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            width=150,
            height=100,
            padding=15,
            border_radius=10,
            bgcolor=ft.Colors.WHITE,
            shadow=ft.BoxShadow(
                spread_radius=1,
                blur_radius=10,
                color=ft.Colors.with_opacity(0.1, ft.Colors.BLACK),
            ),
        )
    
    def build_data_import(self):
        """Veri yükleme görünümü"""
        # Status text referanslarını oluştur
        self.file_status_texts = {
            "target": ft.Text(
                "✅ Yüklendi" if self.loaded_files["target"] else "Dosya seçilmedi",
                size=12,
                color=ft.Colors.GREEN_700 if self.loaded_files["target"] else ft.Colors.GREY_500
            ),
            "sellout": ft.Text(
                "✅ Yüklendi" if self.loaded_files["sellout"] else "Dosya seçilmedi",
                size=12,
                color=ft.Colors.GREEN_700 if self.loaded_files["sellout"] else ft.Colors.GREY_500
            ),
            "visit": ft.Text(
                "✅ Yüklendi" if self.loaded_files["visit"] else "Dosya seçilmedi",
                size=12,
                color=ft.Colors.GREEN_700 if self.loaded_files["visit"] else ft.Colors.GREY_500
            ),
            "order": ft.Text(
                "✅ Yüklendi" if self.loaded_files["order"] else "Dosya seçilmedi",
                size=12,
                color=ft.Colors.GREEN_700 if self.loaded_files["order"] else ft.Colors.GREY_500
            ),
        }
        
        return ft.Column(
            [
                ft.Text("📥 Veri Yükle", size=28, weight=ft.FontWeight.BOLD),
                ft.Divider(),
                ft.Text("Gerekli Dosyalar", size=18, weight=ft.FontWeight.W_500),
                ft.Container(height=10),
                
                # Hedef Dosyası
                self._create_upload_row(
                    "Hedef Dosyası", 
                    "Target25.xlsx", 
                    "target",
                    self.file_status_texts["target"]
                ),
                
                # Satış Verisi
                self._create_upload_row(
                    "Satış Verisi", 
                    "Sell_Out.xlsx", 
                    "sellout",
                    self.file_status_texts["sellout"]
                ),
                
                # Ziyaret Detay
                self._create_upload_row(
                    "Ziyaret Detay", 
                    "Ziyaret_Detay.xlsx", 
                    "visit",
                    self.file_status_texts["visit"]
                ),
                
                # Sipariş Verisi
                self._create_upload_row(
                    "Sipariş Verisi", 
                    "Siparis.xlsx", 
                    "order",
                    self.file_status_texts["order"]
                ),
                
                ft.Container(height=20),
                ft.Row([
                    ft.ElevatedButton(
                        "Tümünü İşle",
                        icon=ft.Icons.PLAY_ARROW,
                        on_click=self._process_all_data,
                        bgcolor=ft.Colors.BLUE,
                        color=ft.Colors.WHITE,
                        style=ft.ButtonStyle(
                            padding=ft.padding.symmetric(horizontal=30, vertical=15),
                        ),
                    ),
                    ft.Container(width=10),
                    ft.OutlinedButton(
                        "Temizle",
                        icon=ft.Icons.CLEAR_ALL,
                        on_click=self._clear_all_files,
                    ),
                ]),
            ],
            scroll=ft.ScrollMode.AUTO,
        )
    
    def _create_upload_row(self, label: str, hint: str, file_type: str, status_text: ft.Text):
        """Dosya yükleme satırı"""
        return ft.Container(
            content=ft.Row(
                [
                    ft.Icon(
                        ft.Icons.CHECK_CIRCLE if self.loaded_files.get(file_type) else ft.Icons.INSERT_DRIVE_FILE, 
                        color=ft.Colors.GREEN if self.loaded_files.get(file_type) else ft.Colors.GREY_600
                    ),
                    ft.Column(
                        [
                            ft.Text(label, weight=ft.FontWeight.W_500),
                            ft.Text(hint, size=12, color=ft.Colors.GREY_500),
                            status_text,
                        ],
                        spacing=2,
                        expand=True,
                    ),
                    ft.ElevatedButton(
                        "Dosya Seç",
                        icon=ft.Icons.FOLDER_OPEN,
                        on_click=lambda e, ft=file_type: self._pick_file(ft),
                    ),
                ],
            ),
            padding=15,
            bgcolor=ft.Colors.GREEN_50 if self.loaded_files.get(file_type) else ft.Colors.GREY_50,
            border_radius=8,
            margin=ft.margin.only(bottom=10),
        )
    
    def _pick_file(self, file_type: str):
        """Dosya seçme dialogunu aç"""
        if file_type in self.file_pickers:
            self.file_pickers[file_type].pick_files(
                allowed_extensions=["xlsx", "xls"],
                dialog_title=f"Dosya Seç",
                allow_multiple=False,
            )
    
    def _process_all_data(self, e):
        """Tüm verileri işle"""
        loaded_count = sum(1 for v in self.loaded_files.values() if v is not None)
        
        if loaded_count == 0:
            self.show_snackbar("⚠️ Lütfen önce dosya yükleyin!", ft.Colors.ORANGE_700)
            return
        
        # İşleme başla
        self.show_snackbar(f"⏳ {loaded_count} dosya işleniyor...", ft.Colors.BLUE_700)
        
        # Dosyaları yükle
        results = []
        
        if self.loaded_files["target"]:
            result = self.data_loader.load_target_file(self.loaded_files["target"])
            results.append(("Hedef", result))
        
        if self.loaded_files["sellout"]:
            result = self.data_loader.load_sellout_file(self.loaded_files["sellout"])
            results.append(("Satış", result))
        
        if self.loaded_files["visit"]:
            result = self.data_loader.load_visit_file(self.loaded_files["visit"])
            results.append(("Ziyaret", result))
        
        if self.loaded_files["order"]:
            result = self.data_loader.load_order_file(self.loaded_files["order"])
            results.append(("Sipariş", result))
        
        # Sonuçları göster
        success_count = sum(1 for _, r in results if r.success)
        
        if success_count == len(results):
            self.show_snackbar(f"✅ Tüm dosyalar başarıyla işlendi! ({success_count} dosya)", ft.Colors.GREEN_700)
        else:
            self.show_snackbar(f"⚠️ {success_count}/{len(results)} dosya işlendi. Bazı hatalar oluştu.", ft.Colors.ORANGE_700)
        
        # Dashboard'u güncelle
        self.page.update()
    
    def _clear_all_files(self, e):
        """Tüm dosya seçimlerini temizle"""
        self.loaded_files = {
            "target": None,
            "sellout": None,
            "visit": None,
            "order": None
        }
        self.show_snackbar("🗑️ Tüm dosya seçimleri temizlendi", ft.Colors.GREY_700)
        
        # Sayfayı yeniden oluştur
        self.content_area.content = self.build_data_import()
        self.page.update()
    
    def build_performance(self):
        """Performans görünümü"""
        return ft.Column(
            [
                ft.Text("📊 Performans", size=28, weight=ft.FontWeight.BOLD),
                ft.Divider(),
                ft.Tabs(
                    selected_index=0,
                    tabs=[
                        ft.Tab(text="ST Bazlı", icon=ft.Icons.PERSON),
                        ft.Tab(text="BM Bazlı", icon=ft.Icons.GROUP),
                        ft.Tab(text="Bölge Bazlı", icon=ft.Icons.MAP),
                        ft.Tab(text="Ürün Bazlı", icon=ft.Icons.INVENTORY),
                    ],
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.INFO_OUTLINE, size=48, color=ft.Colors.GREY_400),
                        ft.Container(height=10),
                        ft.Text(
                            "Performans verileri için önce veri yüklemeniz gerekiyor.",
                            color=ft.Colors.GREY_600,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Container(height=10),
                        ft.TextButton(
                            "Veri Yükle sayfasına git",
                            icon=ft.Icons.ARROW_FORWARD,
                            on_click=lambda e: self._go_to_page(1),
                        ),
                    ], 
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40,
                    alignment=ft.alignment.center,
                ),
            ],
        )
    
    def _go_to_page(self, index: int):
        """Belirli bir sayfaya git"""
        self.nav_rail.selected_index = index
        views = {
            0: self.build_dashboard,
            1: self.build_data_import,
            2: self.build_performance,
            3: self.build_incentive,
            4: self.build_reports,
            5: self.build_settings,
        }
        self.content_area.content = views.get(index, self.build_dashboard)()
        self.page.update()
    
    def build_incentive(self):
        """Prim hesaplama görünümü"""
        return ft.Column(
            [
                ft.Text("💰 Prim Hesaplama", size=28, weight=ft.FontWeight.BOLD),
                ft.Divider(),
                ft.Row(
                    [
                        ft.Dropdown(
                            label="Yıl",
                            options=[ft.dropdown.Option("2025")],
                            value="2025",
                            width=120,
                        ),
                        ft.Dropdown(
                            label="Çeyrek",
                            options=[
                                ft.dropdown.Option("Q1", "Q1 (Oca-Mar)"),
                                ft.dropdown.Option("Q2", "Q2 (Nis-Haz)"),
                                ft.dropdown.Option("Q3", "Q3 (Tem-Eyl)"),
                                ft.dropdown.Option("Q4", "Q4 (Eki-Ara)"),
                            ],
                            value="Q4",
                            width=180,
                        ),
                        ft.ElevatedButton(
                            "Hesapla",
                            icon=ft.Icons.CALCULATE,
                            on_click=self._calculate_incentive,
                            bgcolor=ft.Colors.GREEN,
                            color=ft.Colors.WHITE,
                        ),
                    ],
                ),
                ft.Container(height=20),
                ft.Text("KPI Ağırlıkları", size=18, weight=ft.FontWeight.W_500),
                ft.DataTable(
                    columns=[
                        ft.DataColumn(ft.Text("KPI")),
                        ft.DataColumn(ft.Text("Ağırlık")),
                        ft.DataColumn(ft.Text("Min Eşik")),
                        ft.DataColumn(ft.Text("Max Eşik")),
                    ],
                    rows=[
                        ft.DataRow(cells=[
                            ft.DataCell(ft.Text("Satış Hacmi")),
                            ft.DataCell(ft.Text("%60")),
                            ft.DataCell(ft.Text("%85")),
                            ft.DataCell(ft.Text("%165")),
                        ]),
                        ft.DataRow(cells=[
                            ft.DataCell(ft.Text("Dağılım")),
                            ft.DataCell(ft.Text("%15")),
                            ft.DataCell(ft.Text("%85")),
                            ft.DataCell(ft.Text("%165")),
                        ]),
                        ft.DataRow(cells=[
                            ft.DataCell(ft.Text("Rota Uyumu")),
                            ft.DataCell(ft.Text("%15")),
                            ft.DataCell(ft.Text("%85")),
                            ft.DataCell(ft.Text("%165")),
                        ]),
                        ft.DataRow(cells=[
                            ft.DataCell(ft.Text("Sipariş Başarısı")),
                            ft.DataCell(ft.Text("%10")),
                            ft.DataCell(ft.Text("%85")),
                            ft.DataCell(ft.Text("%165")),
                        ]),
                    ],
                ),
            ],
            scroll=ft.ScrollMode.AUTO,
        )
    
    def _calculate_incentive(self, e):
        """Prim hesapla"""
        if not self.data_loader.loaded_data:
            self.show_snackbar("⚠️ Önce veri yüklemeniz gerekiyor!", ft.Colors.ORANGE_700)
            return
        
        self.show_snackbar("⏳ Prim hesaplanıyor...", ft.Colors.BLUE_700)
        # TODO: Gerçek hesaplama implementasyonu
        self.show_snackbar("✅ Prim hesaplama tamamlandı!", ft.Colors.GREEN_700)
    
    def build_reports(self):
        """Raporlar görünümü"""
        return ft.Column(
            [
                ft.Text("📋 Raporlar", size=28, weight=ft.FontWeight.BOLD),
                ft.Divider(),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.TABLE_CHART),
                    title=ft.Text("ST Performans Kartı"),
                    subtitle=ft.Text("Bireysel scorecard raporu"),
                    trailing=ft.IconButton(
                        ft.Icons.DOWNLOAD,
                        on_click=lambda e: self._download_report("st_scorecard"),
                    ),
                ),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.GROUPS),
                    title=ft.Text("BM Özet Raporu"),
                    subtitle=ft.Text("Bölge müdürü bazlı performans"),
                    trailing=ft.IconButton(
                        ft.Icons.DOWNLOAD,
                        on_click=lambda e: self._download_report("bm_summary"),
                    ),
                ),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.INVENTORY_2),
                    title=ft.Text("Ürün Grubu Analizi"),
                    subtitle=ft.Text("Ürün bazlı hedef/gerçekleşme"),
                    trailing=ft.IconButton(
                        ft.Icons.DOWNLOAD,
                        on_click=lambda e: self._download_report("product_analysis"),
                    ),
                ),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.ROUTE),
                    title=ft.Text("Ziyaret Uyum Raporu"),
                    subtitle=ft.Text("Plan vs gerçekleşen ziyaretler"),
                    trailing=ft.IconButton(
                        ft.Icons.DOWNLOAD,
                        on_click=lambda e: self._download_report("visit_compliance"),
                    ),
                ),
                ft.ListTile(
                    leading=ft.Icon(ft.Icons.PAYMENTS),
                    title=ft.Text("Çeyreklik Prim Raporu"),
                    subtitle=ft.Text("Prim hak kazanan ST listesi"),
                    trailing=ft.IconButton(
                        ft.Icons.DOWNLOAD,
                        on_click=lambda e: self._download_report("bonus_report"),
                    ),
                ),
            ],
            scroll=ft.ScrollMode.AUTO,
        )
    
    def _download_report(self, report_type: str):
        """Rapor indir"""
        if not self.data_loader.loaded_data:
            self.show_snackbar("⚠️ Önce veri yüklemeniz gerekiyor!", ft.Colors.ORANGE_700)
            return
        
        self.show_snackbar(f"⏳ {report_type} raporu oluşturuluyor...", ft.Colors.BLUE_700)
        # TODO: Gerçek rapor oluşturma implementasyonu
        self.show_snackbar(f"✅ Rapor oluşturuldu!", ft.Colors.GREEN_700)
    
    def build_settings(self):
        """Ayarlar görünümü"""
        return ft.Column(
            [
                ft.Text("⚙️ Ayarlar", size=28, weight=ft.FontWeight.BOLD),
                ft.Divider(),
                ft.ExpansionPanelList(
                    expand_icon_color=ft.Colors.BLUE,
                    elevation=1,
                    controls=[
                        ft.ExpansionPanel(
                            header=ft.ListTile(title=ft.Text("ST Yönetimi")),
                            content=ft.Container(
                                content=ft.Text("ST ekleme, çıkarma ve düzenleme işlemleri"),
                                padding=10,
                            ),
                        ),
                        ft.ExpansionPanel(
                            header=ft.ListTile(title=ft.Text("Brick Yönetimi")),
                            content=ft.Container(
                                content=ft.Text("Brick-ST atama işlemleri"),
                                padding=10,
                            ),
                        ),
                        ft.ExpansionPanel(
                            header=ft.ListTile(title=ft.Text("Ürün Grupları")),
                            content=ft.Container(
                                content=ft.Text("Ürün grubu tanımları ve ağırlıkları"),
                                padding=10,
                            ),
                        ),
                        ft.ExpansionPanel(
                            header=ft.ListTile(title=ft.Text("KPI Ayarları")),
                            content=ft.Container(
                                content=ft.Text("KPI ağırlıkları ve eşik değerleri"),
                                padding=10,
                            ),
                        ),
                    ],
                ),
            ],
            scroll=ft.ScrollMode.AUTO,
        )


def main(page: ft.Page):
    """Uygulama giriş noktası"""
    PharmaSalesApp(page)


if __name__ == "__main__":
    ft.app(target=main)
