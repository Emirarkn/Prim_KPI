# 🖥️ VS Code Kurulum ve Kullanım Rehberi

## 📋 Gereksinimler

- **Python 3.10+** ([İndir](https://www.python.org/downloads/))
- **VS Code** ([İndir](https://code.visualstudio.com/))
- **Git** (opsiyonel, [İndir](https://git-scm.com/downloads))

---

## 🚀 Hızlı Başlangıç (Windows)

### Adım 1: Projeyi Aç
1. Zip dosyasını bir klasöre çıkart
2. VS Code'u aç
3. `File` → `Open Folder` → Proje klasörünü seç

### Adım 2: Kurulum
**Seçenek A - Otomatik (Önerilen):**
1. `setup.bat` dosyasına çift tıkla
2. Kurulum tamamlanana kadar bekle

**Seçenek B - Manuel:**
```powershell
# PowerShell'de:
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### Adım 3: Çalıştır
- **F5** tuşuna bas, veya
- `run.bat` dosyasına çift tıkla

---

## 📁 VS Code Arayüzü

### Sol Panel
```
📂 EXPLORER (Dosya Gezgini)
├── 📁 .vscode/          → VS Code ayarları
├── 📁 config/           → JSON konfigürasyonlar
├── 📁 data/sample/      → Örnek veriler
├── 📁 docs/             → Belgeler
├── 📁 src/              → Kaynak kodlar
├── 📁 tests/            → Test dosyaları
├── 📄 requirements.txt  → Python bağımlılıkları
├── 📄 setup.bat         → Kurulum scripti
└── 📄 run.bat           → Çalıştırma scripti
```

### Alt Panel
- **TERMINAL**: Komut satırı
- **PROBLEMS**: Kod hataları
- **OUTPUT**: Çıktılar
- **DEBUG CONSOLE**: Debug bilgileri

---

## ▶️ Çalıştırma Yöntemleri

### 1. Debug Modunda (Önerilen)
1. Sol panelde **Run and Debug** (Ctrl+Shift+D)
2. Üstten **"🚀 Ana Uygulama (Flet)"** seç
3. **▶️ Start Debugging (F5)**

### 2. Terminal'den
```powershell
# PowerShell'de:
.\venv\Scripts\Activate.ps1
python src/main.py
```

### 3. Batch Dosyası ile
- `run.bat` dosyasına çift tıkla

---

## 🧪 Test Çalıştırma

### VS Code Test Explorer
1. Sol panelde **Testing** ikonuna tıkla (şişe ikonu)
2. **Run All Tests** butonuna bas

### Terminal'den
```powershell
.\venv\Scripts\pytest tests/ -v
```

### Debug Modunda
1. **Run and Debug** paneli
2. **"🧪 Testleri Çalıştır"** seç
3. **F5**

---

## ⚡ Faydalı Kısayollar

| Kısayol | İşlev |
|---------|-------|
| `F5` | Debug başlat |
| `Ctrl+F5` | Debug'sız çalıştır |
| `Shift+F5` | Debug durdur |
| `Ctrl+Shift+P` | Komut paleti |
| `Ctrl+`` ` | Terminal aç/kapat |
| `Ctrl+B` | Sol panel aç/kapat |
| `Ctrl+J` | Alt panel aç/kapat |
| `Ctrl+S` | Kaydet |
| `Ctrl+Shift+S` | Tümünü kaydet |

---

## 🔧 Görevler (Tasks)

`Ctrl+Shift+P` → "Tasks: Run Task" yazın:

| Görev | Açıklama |
|-------|----------|
| 🔧 Sanal Ortam Oluştur | Yeni venv ve bağımlılıklar |
| 📦 Bağımlılıkları Yükle | Sadece pip install |
| 🚀 Uygulamayı Başlat | main.py çalıştır |
| 🧪 Testleri Çalıştır | pytest |
| 🧹 Kod Formatla | Black formatter |
| 🔍 Lint Kontrolü | Flake8 |

---

## 🐛 Debug İpuçları

### Breakpoint Koyma
1. Kod satırının solundaki boşluğa tıkla (kırmızı nokta)
2. F5 ile debug başlat
3. Program o satırda duracak

### Değişken İzleme
- **VARIABLES** panelinde tüm değişkenleri gör
- **WATCH** paneline izlemek istediğin değişkeni ekle

### Adım Adım İlerleme
| Buton | Kısayol | İşlev |
|-------|---------|-------|
| ▶️ Continue | F5 | Sonraki breakpoint'e git |
| ⤵️ Step Over | F10 | Satırı atla |
| ⬇️ Step Into | F11 | Fonksiyonun içine gir |
| ⬆️ Step Out | Shift+F11 | Fonksiyondan çık |

---

## ❓ Sık Karşılaşılan Sorunlar

### "Python not found"
```powershell
# Python'ı PATH'e ekleyin veya tam yolu belirtin
C:\Users\KULLANICI\AppData\Local\Programs\Python\Python312\python.exe -m venv venv
```

### "Module not found"
```powershell
# Sanal ortamı aktive edin
.\venv\Scripts\Activate.ps1

# Bağımlılıkları yükleyin
pip install -r requirements.txt
```

### VS Code Python interpreter bulamıyor
1. `Ctrl+Shift+P`
2. "Python: Select Interpreter" yaz
3. `.\venv\Scripts\python.exe` seç

### Flet penceresi açılmıyor
```powershell
# Flet'i tekrar yükle
pip uninstall flet
pip install flet
```

---

## 📞 Yardım

- **Flet Docs**: https://flet.dev/docs/
- **VS Code Python**: https://code.visualstudio.com/docs/python/python-tutorial
- **Python Docs**: https://docs.python.org/3/
